﻿namespace build_shopping_cart.Models
{
    public class Cart
    {
        public Product Product { get; set; }

        public int Quantity { get; set; }
    }
}
